    <footer class="bg-light border-top mt-5 py-3 text-center text-muted" style="font-size: 0.875rem;">
        <div class="container-fluid">
            <p class="mb-0">&copy; 2026 <strong>Alfa IT Solutions</strong>. All rights reserved. | Todo Talenta Digital</p>
        </div>
    </footer>
